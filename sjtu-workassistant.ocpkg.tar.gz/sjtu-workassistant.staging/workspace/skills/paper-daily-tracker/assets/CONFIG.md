# 配置说明

## 环境变量

### 数据源配置

| 变量 | 说明 | 示例 |
|------|------|------|
| `SOURCES` | 数据源列表，用逗号分隔 | `arxiv,cnki` |
| `ARXIV_CATEGORIES` | arXiv 分类 | `cs.AI,cs.LG,cs.CL,cs.CV` |
| `ARXIV_DAYS` | 抓取最近几天的论文 | `1` |
| `CNKI_KEYWORDS` | CNKI 搜索关键词 | `LLM,大模型` |

### 过滤配置

| 变量 | 说明 | 示例 |
|------|------|------|
| `KEYWORDS` | 保留关键词，满足任一即保留 | `LLM,Transformer` |
| `EXCLUDE_KEYWORDS` | 排除关键词 | `生物学,医学` |
| `MAX_PAPERS` | 总论文数上限 | `20` |
| `MAX_PAPERS_PER_SOURCE` | 每个来源的论文数上限 | `10` |

### 功能开关

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `ENABLE_TRANSLATION` | 是否使用 LLM 翻译摘要 | `true` |
| `ENABLE_EMAIL` | 是否发送邮件 | `true` |
| `ENABLE_DEDUP` | 是否启用去重 | `true` |

### LLM 配置

| 变量 | 说明 | 示例 |
|------|------|------|
| `LLM_API_URL` | API 端点 (OpenAI 兼容) | `https://models.sjtu.edu.cn/api/v1` |
| `LLM_API_KEY` | API 密钥 | `sk-xxx` |
| `LLM_MODEL` | 模型名称 | `minimax-m2.5` |
| `LLM_TIMEOUT` | 超时时间(秒) | `600` |
| `LLM_SOURCE_LANG` | 源语言 | `English` |
| `LLM_TARGET_LANG` | 目标语言 | `Chinese` |

### 邮件配置

| 变量 | 说明 | 示例 |
|------|------|------|
| `SMTP_HOST` | SMTP 服务器 | `mail.sjtu.edu.cn` |
| `SMTP_PORT` | SMTP 端口 | `465` |
| `SMTP_USER` | 用户名 | `user@sjtu.edu.cn` |
| `SMTP_PASSWORD` | 密码 | `xxx` |
| `EMAIL_FROM` | 发件人 | `user@sjtu.edu.cn` |
| `EMAIL_TO` | 收件人 | `recipient@example.com` |
| `EMAIL_SUBJECT` | 邮件主题 | `论文简报` |

## 常用 arXiv 分类

- **AI**: `cs.AI` 人工智能
- **机器学习**: `cs.LG` Learning, `stat.ML`
- **NLP**: `cs.CL` Computation and Language
- **计算机视觉**: `cs.CV`
- **神经网络**: `cs.NE` Neuro-Evolution
- **机器人**: `cs.RO`

## 定时任务

使用 crontab:

```bash
# 每天早上 8 点运行
0 8 * * * cd /path/to/paper-daily-tracker && python scripts/run.py fetch
```

或使用 OpenClaw cron:
```bash
openclaw cron add --name paper-daily --schedule "0 8 * * *" --command "python scripts/run.py fetch"
```