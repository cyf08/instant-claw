#!/usr/bin/env python3
"""
PaperMind API 客户端
用于调用 PaperMind 的精读和翻译功能
"""

import requests
import json
import sys
import os
from typing import Optional, Dict, Any


class PaperMindClient:
    def __init__(self, base_url: str, api_key: str = ""):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()
        if api_key:
            self.session.headers.update({'Authorization': f'Bearer {api_key}'})

    def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        response = self.session.request(method, url, **kwargs)
        response.raise_for_status()
        return response.json()

    def deep_read(self, paper_url: str) -> Dict[str, Any]:
        """
        论文精读
        通过 URL 精读论文
        """
        # 先获取论文
        paper_data = self._request('POST', '/pipelines/skim', json={
            'url': paper_url
        })

        # 精读
        paper_id = paper_data.get('id')
        if paper_id:
            self._request('POST', f'/pipelines/deep/{paper_id}')
            return self._request('GET', f'/papers/{paper_id}')

        return paper_data

    def translate(self, paper_id: str, mode: str = 'fast') -> Dict[str, Any]:
        """
        翻译论文
        mode: 'fast' (快速翻译) 或 'layout' (布局保留)
        """
        return self._request('POST', f'/wiki/paper/{paper_id}', json={
            'mode': mode
        })

    def get_translation(self, paper_id: str) -> Dict[str, Any]:
        """获取翻译结果"""
        return self._request('GET', f'/wiki/paper/{paper_id}')


def main():
    if len(sys.argv) < 3:
        print("Usage: papermind_client.py <command> <paper_url_or_id> [options]")
        print("Commands:")
        print("  deep-read <url>     - 精读论文")
        print("  translate <id>      - 翻译论文")
        print("  get-translation <id> - 获取翻译结果")
        sys.exit(1)

    command = sys.argv[1]
    arg = sys.argv[2]

    # 从环境变量获取配置
    base_url = os.environ.get('PAPERMIND_URL', 'http://localhost:8002')
    api_key = os.environ.get('PAPERMIND_API_KEY', '')

    client = PaperMindClient(base_url, api_key)

    try:
        if command == 'deep-read':
            result = client.deep_read(arg)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif command == 'translate':
            mode = sys.argv[3] if len(sys.argv) > 3 else 'fast'
            result = client.translate(arg, mode)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif command == 'get-translation':
            result = client.get_translation(arg)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"Unknown command: {command}")
            sys.exit(1)
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()