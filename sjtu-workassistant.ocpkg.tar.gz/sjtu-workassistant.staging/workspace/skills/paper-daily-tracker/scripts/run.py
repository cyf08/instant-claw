#!/usr/bin/env python3
"""
Paper Daily Finder 主脚本
协调整个论文发现和推送流程
支持多数据源: arXiv, CNKI
"""

import os
import sys
import json
import subprocess
import shutil
from datetime import datetime
from typing import List, Dict, Any, Optional

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
TEMP_DIR = os.path.join(PROJECT_DIR, 'temp')
SENT_PAPERS_FILE = os.path.join(PROJECT_DIR, 'temp', 'sent_papers.json')
os.makedirs(TEMP_DIR, exist_ok=True)

# 导入模块
from fetchers import fetch_arxiv_papers, fetch_cnki_papers


def load_sent_papers() -> set:
    """加载已发送的论文ID集合"""
    if os.path.exists(SENT_PAPERS_FILE):
        try:
            with open(SENT_PAPERS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return set(data.get('sent_ids', []))
        except:
            return set()
    return set()


def save_sent_papers(sent_ids: set):
    """保存已发送的论文ID"""
    data = {'sent_ids': list(sent_ids)}
    with open(SENT_PAPERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)


def load_config() -> dict:
    """加载配置文件 (优先使用 .env)"""
    from config import load_config as load_env_config
    return load_env_config()


def resolve_env_vars(config: dict) -> dict:
    """解析环境变量"""
    result = {}
    for key, value in config.items():
        if isinstance(value, dict):
            result[key] = resolve_env_vars(value)
        elif isinstance(value, str) and value.startswith('${') and value.endswith('}'):
            env_var = value[2:-1]
            result[key] = os.environ.get(env_var, '')
        else:
            result[key] = value
    return result


def run_command(cmd: List[str], cwd: Optional[str] = None) -> subprocess.CompletedProcess:
    """运行命令"""
    print(f"Running: {' '.join(cmd)}")
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


def fetch_rss(category: str, max_results: int = 50) -> str:
    """抓取 arXiv RSS"""
    fetch_script = os.path.join(SCRIPT_DIR, 'fetch_rss.sh')
    output_file = os.path.join(TEMP_DIR, f'arxiv_{category}_{os.getpid()}.xml')

    cmd = ['bash', fetch_script, category, str(max_results), output_file]
    result = run_command(cmd)

    if result.returncode != 0:
        raise RuntimeError(f"Failed to fetch RSS: {result.stderr}")

    return output_file


def filter_papers(xml_file: str, config: dict) -> List[Dict[str, Any]]:
    """过滤论文"""
    filter_script = os.path.join(SCRIPT_DIR, 'filter_papers.py')
    cmd = ['python3', filter_script, xml_file]

    result = run_command(cmd)

    if result.returncode != 0:
        raise RuntimeError(f"Failed to filter papers: {result.stderr}")

    return json.loads(result.stdout)


def translate_papers(papers: List[Dict[str, Any]], config: dict) -> Dict[str, str]:
    """使用 LLM 翻译论文"""
    from llm_translator import translate_papers as llm_translate
    
    llm_config = config.get('llm', {})
    if not llm_config.get('api_url'):
        print("Warning: No LLM config, skipping translation")
        return {}

    print(f"\n=== Translating {len(papers)} papers ===")
    translated = llm_translate(papers, config)
    print(f"Translated {len(translated)} papers")
    return translated


def generate_pdf(papers: List[Dict[str, Any]], translated: Dict[str, str]) -> str:
    """生成 PDF"""
    papers_file = os.path.join(TEMP_DIR, f'papers_{os.getpid()}.json')
    translated_file = os.path.join(TEMP_DIR, f'translated_{os.getpid()}.json')

    with open(papers_file, 'w', encoding='utf-8') as f:
        json.dump(papers, f, ensure_ascii=False)

    with open(translated_file, 'w', encoding='utf-8') as f:
        json.dump(translated, f, ensure_ascii=False)

    output_pdf = os.path.join(TEMP_DIR, f'arxiv_daily_{datetime.now().strftime("%Y%m%d")}.pdf')

    generate_script = os.path.join(SCRIPT_DIR, 'generate_pdf.py')
    cmd = ['python3', generate_script, papers_file, translated_file, output_pdf]
    result = run_command(cmd)

    # 清理临时文件
    for f in [papers_file, translated_file]:
        if os.path.exists(f):
            os.unlink(f)

    if result.returncode != 0:
        raise RuntimeError(f"Failed to generate PDF: {result.stderr}")

    return output_pdf


def send_email_notification(papers: List[Dict[str, Any]], pdf_file: str, config: dict, translated: Dict[str, str] = None):
    """发送邮件通知"""
    if translated is None:
        translated = {}
    # 生成详细邮件内容
    papers_html = ""
    for p in papers:
        title = p.get('title', '')
        authors = ', '.join(p.get('authors', [])[:5])
        paper_id = p.get('id', '')
        
        # 解析翻译内容
        translated_text = translated.get(paper_id, '')
        if translated_text and isinstance(translated_text, str):
            # 格式: 【标题】xxx\n\n【摘要】xxx
            title_trans = ''
            summary_trans = ''
            if '【标题】' in translated_text:
                parts = translated_text.split('【摘要】')
                title_trans = parts[0].replace('【标题】', '').strip()
                summary_trans = parts[1].strip() if len(parts) > 1 else ''
            title = title_trans or p.get('title', '')
            summary = summary_trans or p.get('summary', '')
        else:
            title = p.get('title', '')
            summary = p.get('summary', '')
        
        pdf_url = p.get('pdf_url', '')
        categories = ', '.join(p.get('categories', []))

        papers_html += f"""
        <div style="margin-bottom: 30px; padding: 15px; background: #f5f5f5; border-radius: 8px;">
            <h3 style="margin: 0 0 10px 0; color: #1a1a1a;">
                <a href="{pdf_url}" style="color: #0066cc; text-decoration: none;">{title}</a>
            </h3>
            <p style="margin: 5px 0; color: #666; font-size: 14px;">
                <strong>作者:</strong> {authors}
            </p>
            <p style="margin: 5px 0; color: #666; font-size: 14px;">
                <strong>分类:</strong> {categories}
            </p>
            <p style="margin: 10px 0 0 0; color: #333; font-size: 13px; line-height: 1.6;">
                <strong>摘要:</strong> {summary}
            </p>
        </div>
        """

    body_html = f"""
    <html>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; color: #333;">
        <h1 style="color: #1a1a1a; border-bottom: 2px solid #0066cc; padding-bottom: 10px;">
            📚 今日 arXiv/CNKI 论文精选
        </h1>
        <p style="color: #666; font-size: 14px;">
            共发现 <strong>{len(papers)}</strong> 篇论文，按关键词过滤推送。
        </p>
        <div style="margin-top: 20px;">
            {papers_html}
        </div>
        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
        <p style="color: #999; font-size: 12px; text-align: center;">
            由 Paper Daily Tracker 自动生成<br>
            生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        </p>
    </body>
    </html>
    """

    subject = f"📚 Paper Daily Tracker - {datetime.now().strftime('%Y-%m-%d')} 论文精选 ({len(papers)} 篇)"

    send_email_script = os.path.join(SCRIPT_DIR, 'send_email.py')

    # 检查 PDF 是否存在
    attachment = pdf_file if os.path.exists(pdf_file) else ""

    cmd = ['python3', send_email_script, '.env', subject, body_html, attachment]
    result = run_command(cmd)

    if result.returncode != 0:
        raise RuntimeError(f"Failed to send email: {result.stderr}")


def init_config():
    """初始化配置文件"""
    from config import init_config as init_env_config
    init_env_config()


def test_email():
    """测试邮件发送"""
    env_file = '.env'
    if not os.path.exists(env_file):
        print(f"Config file not found: {env_file}")
        print("Please create .env from assets/.env.example")
        sys.exit(1)

    body_html = """
    <html>
    <body>
        <h2>✅ 测试邮件</h2>
        <p>这是 Paper Daily Tracker 的测试邮件。</p>
        <p>如果收到这封邮件，说明邮件配置正确。</p>
    </body>
    </html>
    """

    send_email_script = os.path.join(SCRIPT_DIR, 'send_email.py')
    cmd = ['python3', send_email_script, env_file, "Paper Daily Tracker - 测试邮件", body_html]
    result = run_command(cmd)

    if result.returncode == 0:
        print("Test email sent successfully!")
    else:
        print(f"Failed to send test email: {result.stderr}")
        sys.exit(1)


def run_fetch():
    """执行论文抓取流程"""
    config = load_config()
    config = resolve_env_vars(config)
    
    sources = config.get('sources', ['arxiv'])
    max_papers = config.get('filter', {}).get('max_papers', 20)
    max_per_source = config.get('filter', {}).get('max_papers_per_source', 10)
    enable_translation = config.get('features', {}).get('enable_translation', True)
    enable_email = config.get('features', {}).get('enable_email', True)
    enable_dedup = config.get('features', {}).get('enable_dedup', True)
    
    all_papers = []
    
    for source in sources:
        print(f"\n=== Fetching from {source} ===")
        
        try:
            if source == 'arxiv':
                categories = config.get('arxiv', {}).get('categories', ['cs.AI'])
                days = config.get('arxiv', {}).get('days', 1)
                papers = fetch_arxiv_papers(categories, days=days, max_papers=max_per_source)
                all_papers.extend(papers)
                print(f"Fetched {len(papers)} papers from arXiv")
                
            elif source == 'cnki':
                keywords = config.get('cnki', {}).get('keywords', [])
                if keywords:
                    papers = fetch_cnki_papers(keywords, max_papers=max_per_source)
                    all_papers.extend(papers)
                    print(f"Fetched {len(papers)} papers from CNKI")
                else:
                    print("CNKI keywords not configured, skipping")
                    
        except Exception as e:
            print(f"Error fetching from {source}: {e}")
            continue
    
    if not all_papers:
        print("No papers found")
        sys.exit(1)
    
    # 过滤论文
    print("\n=== Filtering papers ===")
    keywords = config.get('filter', {}).get('keywords', [])
    exclude_keywords = config.get('filter', {}).get('exclude_keywords', [])
    all_papers = filter_papers_by_keywords(all_papers, keywords, exclude_keywords)
    print(f"After filtering: {len(all_papers)} papers")
    
    if not all_papers:
        print("No papers match filters")
        sys.exit(0)
    
    # 去重
    if enable_dedup:
        sent_ids = load_sent_papers()
        original_count = len(all_papers)
        all_papers = [p for p in all_papers if p.get('id', '') not in sent_ids]
        print(f"\n=== Deduplication: {original_count} -> {len(all_papers)} (removed {original_count - len(all_papers)}) ===")
    
    if not all_papers:
        print("No new papers to send")
        sys.exit(0)
    
    # 限制数量
    all_papers = all_papers[:max_papers]
    print(f"\n=== Sending {len(all_papers)} papers ===")
    
    # 翻译
    translated = {}
    if enable_translation:
        print("\n=== Translating papers ===")
        translated = translate_papers(all_papers, config)
    
    # 生成 PDF
    print("\n=== Generating PDF ===")
    pdf_file = generate_pdf(all_papers, translated)
    
    # 发送邮件
    if enable_email:
        print("\n=== Sending email ===")
        send_email_notification(all_papers, pdf_file, config, translated)
        
        # 更新已发送列表
        if enable_dedup:
            new_sent_ids = {p.get('id', '') for p in all_papers}
            sent_ids.update(new_sent_ids)
            save_sent_papers(sent_ids)
            print(f"Updated sent papers list: {len(sent_ids)} total")
    else:
        print("\n=== Email disabled, skipping ===")
    
    print("\n=== Done! ===")


def filter_papers_by_keywords(papers: List[Dict], keywords: List[str], exclude_keywords: List[str]) -> List[Dict]:
    """根据关键词过滤论文"""
    if not keywords:
        return papers
    
    filtered = []
    for paper in papers:
        text = (paper.get('title', '') + ' ' + paper.get('summary', '')).lower()
        
        # 检查是否包含任一关键词
        if any(kw.lower() in text for kw in keywords):
            # 检查是否包含排除关键词
            if exclude_keywords and any(kw.lower() in text for kw in exclude_keywords):
                continue
            filtered.append(paper)
    
    return filtered


def schedule_cron(time_str: str, config: dict):
    """配置定时任务"""
    if ':' in time_str:
        hour, minute = time_str.split(':')
        cron_expr = f"{minute} {hour} * * *"
    else:
        cron_expr = time_str

    # 创建 cron 任务
    from openclaw import cli  # 假设 openclaw 已安装
    # 这里需要调用 openclaw cron 命令
    print(f"Setting up cron: {cron_expr}")
    print("Run: openclaw cron add --name 'arxiv-daily' --cron '{}' --session isolated --message 'arxiv-daily-tracker run' --announce".format(cron_expr))


def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python3 scripts/run.py init           - 初始化配置")
        print("  python3 scripts/run.py fetch          - 抓取论文")
        print("  python3 scripts/run.py test-email     - 测试邮件发送")
        print("  python3 scripts/run.py schedule       - 查看定时任务配置")
        sys.exit(1)

    command = sys.argv[1]

    if command == 'init':
        init_config()
    elif command == 'fetch':
        run_fetch()
    elif command == 'test-email':
        test_email()
    elif command == 'schedule':
        print("定时任务通过 OpenClaw 配置:")
        print("  openclaw cron add \\")
        print("    --name paper-daily \\")
        print('    --cron "0 9 * *" \\')
        print('    --tz "Asia/Shanghai" \\')
        print("    --session isolated \\")
        print('    --message "cd /path/to/paper-daily-tracker && python3 scripts/run.py fetch" \\')
        print("    --announce")
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == '__main__':
    main()
