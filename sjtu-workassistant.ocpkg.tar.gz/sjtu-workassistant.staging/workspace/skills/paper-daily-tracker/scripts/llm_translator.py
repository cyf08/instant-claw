#!/usr/bin/env python3
"""
LLM 翻译模块
直接调用 LLM API 翻译论文摘要
支持 OpenAI-compatible、Anthropic、Ollama
"""

import os
import sys
import json
import requests
from typing import Dict, Any


class LLMTranslator:
    def __init__(self, base_url: str = "", api_key: str = "", model: str = ""):
        self.base_url = base_url or os.environ.get('LLM_API_URL', '') or os.environ.get('LLM_BASE_URL', '')
        self.api_key = api_key or os.environ.get('LLM_API_KEY', '')
        self.model = model or os.environ.get('LLM_MODEL', '')

    def translate(self, text: str, source_lang: str = "English", target_lang: str = "Chinese") -> str:
        """翻译文本"""
        if not text:
            return ""

        # 判断 API 类型
        if 'ollama' in self.base_url.lower() or '11434' in self.base_url:
            return self._translate_ollama(text, source_lang, target_lang)
        elif 'anthropic' in self.base_url.lower():
            return self._translate_anthropic(text, source_lang, target_lang)
        else:
            return self._translate_openai(text, source_lang, target_lang)

    def _translate_ollama(self, text: str, source: str, target: str) -> str:
        """使用 Ollama API"""
        url = f"{self.base_url.rstrip('/v1')}/api/chat"
        prompt = f"""请将以下{source}学术论文摘要翻译成{target}。
只输出翻译结果，不要解释。

原文：
{text}

翻译："""
        data = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False
        }
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        response = requests.post(url, json=data, headers=headers, timeout=120)
        response.raise_for_status()
        return response.json()['message']['content']

    def _translate_openai(self, text: str, source: str, target: str) -> str:
        """使用 OpenAI 兼容 API"""
        url = self.base_url
        if '/chat/completions' not in url:
            url = f"{url.rstrip('/v1')}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        prompt = f"""请将以下{source}学术论文摘要翻译成{target}。
只输出翻译结果，不要解释。

原文：
{text}

翻译："""
        data = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 4000,
            "temperature": 0.3,
            "thinking": {"type": "disabled"} if hasattr(self, 'model') and 'm2.5' in self.model else None
        }
        # 移除 None 值
        data = {k: v for k, v in data.items() if v is not None}
        response = requests.post(url, headers=headers, json=data, timeout=600)
        response.raise_for_status()
        content = response.json()['choices'][0]['message']['content']
        
        # 移除思考内容 (think/<think>...</think>)
        import re
        content = re.sub(r'<think>.*?</think>\s*', '', content, flags=re.DOTALL)
        return content.strip()

    def _translate_anthropic(self, text: str, source: str, target: str) -> str:
        """使用 Anthropic API"""
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
        prompt = f"""请将以下{source}学术论文摘要翻译成{target}。
只输出翻译结果，不要解释。

原文：
{text}

翻译："""
        data = {
            "model": self.model,
            "max_tokens": 4000,
            "messages": [{"role": "user", "content": prompt}]
        }
        response = requests.post(url, headers=headers, json=data, timeout=120)
        response.raise_for_status()
        return response.json()['content'][0]['text']


def translate_papers(papers: list, config: dict) -> Dict[str, str]:
    """翻译论文列表"""
    llm_config = config.get('llm', {})
    features = config.get('features', {})
    translation_mode = features.get('translation_mode', 'summary')

    translator = LLMTranslator(
        base_url=llm_config.get('api_url', ''),
        api_key=llm_config.get('api_key', ''),
        model=llm_config.get('model', '')
    )

    translated = {}
    for paper in papers:
        paper_id = paper.get('id', '')
        title = paper.get('title', '')
        summary = paper.get('summary', '')

        print(f"Translating: {title[:50]}...")

        # 翻译标题
        translated_title = translator.translate(title) if title else ""

        # 根据模式决定翻译内容
        if translation_mode == 'full':
            # 全文模式：翻译完整摘要（截断到 3000 字符）
            text_to_translate = summary[:3000] if len(summary) > 3000 else summary
        else:
            # 摘要模式：只翻译前 500 字符
            text_to_translate = summary[:500] if len(summary) > 500 else summary

        translated_summary = translator.translate(text_to_translate) if text_to_translate else ""

        translated[paper_id] = f"【标题】{translated_title}\n\n【摘要】{translated_summary}"

    return translated


def main():
    from config import load_config
    config = load_config()

    if len(sys.argv) > 1:
        papers_file = sys.argv[1]
        with open(papers_file, 'r', encoding='utf-8') as f:
            papers = json.load(f)
    else:
        papers = json.load(sys.stdin)

    translated = translate_papers(papers, config)
    print(json.dumps(translated, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()