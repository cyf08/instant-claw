#!/usr/bin/env python3
"""
PDF 生成脚本
将论文翻译内容生成为 PDF
"""

import sys
import json
import os
from datetime import datetime
from typing import Dict, Any, List


def generate_html(papers: List[Dict[str, Any]], translated_contents: Dict[str, str]) -> str:
    """生成 HTML内容"""
    date_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    html_parts = [
        """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Paper Daily Tracker - 论文摘要</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.8; max-width: 800px; margin: 0 auto; padding: 20px; color: #333; }
        h1 { color: #1a1a1a; border-bottom: 2px solid #0066cc; padding-bottom: 10px; }
        h2 { color: #0066cc; margin-top: 30px; }
        .paper { margin-bottom: 40px; padding: 20px; background: #f9f9f9; border-radius: 8px; }
        .paper-title { font-size: 1.2em; font-weight: bold; color: #1a1a1a; }
        .paper-meta { color: #666; font-size: 0.9em; margin: 10px 0; }
        .paper-categories { display: inline-block; background: #e6f3ff; color: #0066cc; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; margin-right: 5px; }
        .paper-link { color: #0066cc; text-decoration: none; }
        .paper-link:hover { text-decoration: underline; }
        .abstract { background: #fff; padding: 15px; border-left: 3px solid #0066cc; margin: 15px 0; }
        .translation { background: #fff; padding: 15px; border-left: 3px solid #28a745; margin: 15px 0; }
        .footer { text-align: center; color: #999; margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; }
    </style>
</head>
<body>
    <h1>Paper Daily Tracker - 今日论文精选</h1>
    <p class="paper-meta">生成时间: """ + date_str + """</p>
"""]

    for paper in papers:
        paper_id = paper.get('id', '')
        title = paper.get('title', '')
        authors = paper.get('authors', [])
        summary = paper.get('summary', '')
        pdf_url = paper.get('pdf_url', '')
        categories = paper.get('categories', [])

        translation = translated_contents.get(paper_id, '')

        html_parts.append(f"""
    <div class="paper">
        <div class="paper-title">{title}</div>
        <div class="paper-meta">
            <strong>作者:</strong> {', '.join(authors)}<br>
            <strong>分类:</strong> {' '.join([f'<span class="paper-categories">{c}</span>' for c in categories])}
        </div>
        <div class="abstract">
            <strong>摘要:</strong><br>
            {summary}
        </div>
""")

        if translation:
            html_parts.append(f"""
        <div class="translation">
            <strong>中文翻译:</strong><br>
            {translation}
        </div>
""")

        if pdf_url:
            html_parts.append(f"""
        <div>
            <a class="paper-link" href="{pdf_url}" target="_blank">📄 查看原文 PDF</a>
        </div>
""")

        html_parts.append("""
    </div>
""")

    html_parts.append("""
    <div class="footer">
        <p>由 Paper Daily Tracker 自动生成</p>
    </div>
</body>
</html>
""")

    return '\n'.join(html_parts)


def html_to_pdf(html_content: str, output_file: str):
    """将 HTML 转换为 PDF"""
    try:
        from weasyprint import HTML
        HTML(string=html_content).write_pdf(output_file)
    except ImportError:
        # 如果没有 weasyprint，保存 HTML 文件
        output_html = output_file.replace('.pdf', '.html')
        with open(output_html, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"Warning: weasyprint not installed, saved HTML instead: {output_html}")
    except Exception as e:
        raise e


def main():
    if len(sys.argv) < 3:
        print("Usage: generate_pdf.py <papers_json> <translated_contents_json> <output_pdf>")
        sys.exit(1)

    papers_json = sys.argv[1]
    translated_json = sys.argv[2]
    output_pdf = sys.argv[3]

    # 读取论文数据
    with open(papers_json, 'r', encoding='utf-8') as f:
        papers = json.load(f)

    # 读取翻译内容
    with open(translated_json, 'r', encoding='utf-8') as f:
        translated_contents = json.load(f)

    # 生成 HTML
    html_content = generate_html(papers, translated_contents)

    # 转换为 PDF
    html_to_pdf(html_content, output_pdf)
    print(f"PDF generated: {output_pdf}")


if __name__ == '__main__':
    main()