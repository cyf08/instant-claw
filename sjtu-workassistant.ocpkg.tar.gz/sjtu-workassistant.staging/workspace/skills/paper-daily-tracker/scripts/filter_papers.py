#!/usr/bin/env python3
"""
arXiv 论文过滤脚本
从 XML 中解析论文并按关键字/作者过滤
支持 arXiv API 和 RSS 格式
"""

import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import List
import yaml
import json


@dataclass
class Paper:
    id: str
    title: str
    summary: str
    authors: List[str]
    published: str
    updated: str
    pdf_url: str
    categories: List[str]


def parse_arxiv_xml(xml_file: str) -> List[Paper]:
    """解析 arXiv API XML 文件"""
    tree = ET.parse(xml_file)
    root = tree.getroot()

    # 处理命名空间
    ns = {'atom': 'http://www.w3.org/2005/Atom', 'arxiv': 'http://arxiv.org/schemas/atom'}

    papers = []
    for entry in root.findall('.//atom:entry', ns):
        # 提取基本信息
        paper_id = entry.find('atom:id', ns).text if entry.find('atom:id', ns) is not None else ''
        title = entry.find('atom:title', ns).text.strip() if entry.find('atom:title', ns) is not None else ''
        summary = entry.find('atom:summary', ns).text.strip() if entry.find('atom:summary', ns) is not None else ''

        # 作者
        authors = []
        for author in entry.findall('atom:author', ns):
            name = author.find('atom:name', ns)
            if name is not None:
                authors.append(name.text)

        # 日期
        published = ''
        updated = ''
        published_elem = entry.find('atom:published', ns)
        if published_elem is not None:
            published = published_elem.text
        updated_elem = entry.find('atom:updated', ns)
        if updated_elem is not None:
            updated = updated_elem.text

        # PDF 链接 - 查找 rel="related" title="pdf" 或直接找 pdf 链接
        pdf_url = ""
        for link in entry.findall('atom:link', ns):
            if link.get('title') == 'pdf' or (link.get('href', '') and link.get('href', '').endswith('.pdf')):
                pdf_url = link.get('href', '')
                break

        # 分类
        categories = []
        for cat in entry.findall('atom:category', ns):
            term = cat.get('term', '')
            if term:
                categories.append(term)

        papers.append(Paper(
            id=paper_id,
            title=title,
            summary=summary,
            authors=authors,
            published=published,
            updated=updated,
            pdf_url=pdf_url,
            categories=categories
        ))

    # 如果没找到，尝试无命名空间
    if not papers:
        for entry in root.findall('.//entry'):
            paper_id = entry.find('id').text if entry.find('id') is not None else ''
            title = entry.find('title').text.strip() if entry.find('title') is not None else ''
            summary = entry.find('summary').text.strip() if entry.find('summary') is not None else ''

            authors = []
            for author in entry.findall('author'):
                name = author.find('name')
                if name is not None:
                    authors.append(name.text)

            published = entry.find('published').text if entry.find('published') is not None else ''
            updated = entry.find('updated').text if entry.find('updated') is not None else ''

            pdf_url = ""
            for link in entry.findall('link'):
                if link.get('title') == 'pdf':
                    pdf_url = link.get('href', '')
                    break

            categories = []
            for cat in entry.findall('category'):
                term = cat.get('term', '')
                if term:
                    categories.append(term)

            papers.append(Paper(
                id=paper_id,
                title=title,
                summary=summary,
                authors=authors,
                published=published,
                updated=updated,
                pdf_url=pdf_url,
                categories=categories
            ))

    return papers


def filter_papers(papers: List[Paper], keywords: List[str], authors: List[str], max_papers: int) -> List[Paper]:
    """过滤论文：匹配关键字或作者"""
    filtered = []

    for paper in papers:
        matched = False

        if keywords:
            title_lower = paper.title.lower()
            summary_lower = paper.summary.lower()
            for kw in keywords:
                if kw.lower() in title_lower or kw.lower() in summary_lower:
                    matched = True
                    break

        if not matched and authors:
            for author in authors:
                author_lower = author.lower()
                for paper_author in paper.authors:
                    if author_lower in paper_author.lower():
                        matched = True
                        break
                if matched:
                    break

        if not keywords and not authors:
            matched = True

        if matched:
            filtered.append(paper)

        if len(filtered) >= max_papers:
            break

    return filtered


def load_config(config_file: str) -> dict:
    """加载配置文件"""
    with open(config_file, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def main():
    if len(sys.argv) < 2:
        print("Usage: filter_papers.py <xml_file> [config_file]")
        sys.exit(1)

    xml_file = sys.argv[1]
    config_file = sys.argv[2] if len(sys.argv) > 2 else None

    keywords = []
    authors = []
    max_papers = 5

    if config_file:
        config = load_config(config_file)
        keywords = config.get('arxiv', {}).get('filters', {}).get('keywords', [])
        authors = config.get('arxiv', {}).get('filters', {}).get('authors', [])
        max_papers = config.get('arxiv', {}).get('max_papers', 5)

    papers = parse_arxiv_xml(xml_file)
    filtered = filter_papers(papers, keywords, authors, max_papers)

    result = [{
        'id': p.id,
        'title': p.title,
        'summary': p.summary,
        'authors': p.authors,
        'published': p.published,
        'pdf_url': p.pdf_url,
        'categories': p.categories
    } for p in filtered]

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()