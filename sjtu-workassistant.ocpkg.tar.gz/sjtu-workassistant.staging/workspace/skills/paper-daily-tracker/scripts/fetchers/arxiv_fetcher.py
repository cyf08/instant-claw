#!/usr/bin/env python3
"""
arXiv 论文抓取器
"""

import os
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import List, Dict
import urllib.request
import urllib.parse


def fetch_arxiv_papers(categories: List[str], days: int = 1, max_papers: int = 10) -> List[Dict]:
    """从 arXiv 获取论文"""
    papers = []
    
    # 计算日期范围
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    for category in categories:
        # 取足够多的论文，然后在代码中按日期过滤（arXiv API 日期查询有 bug）
        fetch_count = max_papers * 3  # 多取一些以确保有足够的近期论文
        url = f"https://export.arxiv.org/api/query?search_query=cat:{category}&start=0&max_results={fetch_count}&sortBy=submittedDate&sortOrder=descending"
        
        try:
            with urllib.request.urlopen(url, timeout=30) as response:
                content = response.read().decode('utf-8')
            
            root = ET.fromstring(content)
            
            for entry in root.findall('{http://www.w3.org/2005/Atom}entry'):
                published = entry.find('{http://www.w3.org/2005/Atom}published').text[:10]
                
                # 代码内日期过滤：只保留近 days 天的论文
                pub_date = datetime.strptime(published, '%Y-%m-%d')
                if pub_date < start_date:
                    continue
                    
                paper = {
                    'id': entry.find('{http://www.w3.org/2005/Atom}id').text,
                    'title': entry.find('{http://www.w3.org/2005/Atom}title').text.replace('\n', ' ').strip(),
                    'summary': entry.find('{http://www.w3.org/2005/Atom}summary').text.replace('\n', ' ').strip(),
                    'published': published,
                    'updated': entry.find('{http://www.w3.org/2005/Atom}updated').text[:10],
                    'authors': [a.find('{http://www.w3.org/2005/Atom}name').text for a in entry.findall('{http://www.w3.org/2005/Atom}author')],
                    'categories': [c.attrib.get('term', '') for c in entry.findall('{http://www.w3.org/2005/Atom}category')],
                    'pdf_url': '',
                    'source': 'arxiv',
                }
                
                # 获取 PDF 链接
                for link in entry.findall('{http://www.w3.org/2005/Atom}link'):
                    if link.attrib.get('title') == 'pdf':
                        paper['pdf_url'] = link.attrib.get('href', '')
                        break
                
                papers.append(paper)
                
        except Exception as e:
            print(f"Error fetching {category}: {e}")
            continue
    
    return papers


if __name__ == '__main__':
    papers = fetch_arxiv_papers(['cs.AI', 'cs.LG'], days=1, max_papers=5)
    for p in papers:
        print(f"- {p['title'][:60]}...")