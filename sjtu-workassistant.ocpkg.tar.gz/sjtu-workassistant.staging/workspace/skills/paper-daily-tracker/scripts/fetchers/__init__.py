#!/usr/bin/env python3
"""
论文抓取器
"""

from .arxiv_fetcher import fetch_arxiv_papers
from .cnki_fetcher import fetch_cnki_papers

__all__ = ['fetch_arxiv_papers', 'fetch_cnki_papers']