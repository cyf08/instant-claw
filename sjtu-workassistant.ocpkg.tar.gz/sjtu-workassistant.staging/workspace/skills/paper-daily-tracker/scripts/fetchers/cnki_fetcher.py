#!/usr/bin/env python3
"""
CNKI 知网论文抓取器
需要 agent-browser 和已登录的浏览器会话
"""

import os
import json
import subprocess
from typing import List, Dict, Optional


CDP_PORT = os.environ.get('CDP_PORT', '9222')  # 默认 9222


def run_agent(cmd: List[str]) -> str:
    """运行 agent-browser 命令"""
    try:
        result = subprocess.run(
            ['agent-browser', '--cdp', CDP_PORT] + cmd,
            capture_output=True, text=True, timeout=120
        )
        return result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return "timeout"
    except FileNotFoundError:
        return "agent-browser not found"


def check_browser() -> bool:
    """检查浏览器是否可用"""
    output = run_agent(['get', 'url'])
    return output and 'error' not in output.lower() and 'not found' not in output.lower()


def open_cnki() -> bool:
    """打开知网（如果浏览器已打开则跳过）"""
    # 先检查当前页面
    current = run_agent(['get', 'url'])
    if 'cnki.net' in current:
        print("Browser already on CNKI, skipping open")
        return True
    
    output = run_agent(['open', 'https://kns.cnki.net/kns8s/defaultresult/index'])
    output += run_agent(['wait', '3000'])
    return 'error' not in output.lower()


def search_cnki(keyword: str) -> bool:
    """搜索关键词"""
    # 先获取页面元素
    run_agent(['snapshot', '-i'])
    
    # 填充搜索框 (ref 需要从 snapshot 获取)
    # 这里返回需要用户手动操作的提示
    fill_result = run_agent(['eval', f'document.querySelector("#txt_SearchKeyword")?.value = "{keyword}"'])
    
    # 点击搜索按钮
    click_result = run_agent(['click', '...'])  # 需要从 snapshot 获取 ref
    
    run_agent(['wait', '5000'])
    return True


def get_search_results() -> List[Dict]:
    """获取搜索结果"""
    # 知网结果表格 selector
    output = run_agent(['eval', '''
        Array.from(document.querySelectorAll('table.result-table-list tbody tr')).slice(0, 10).map((row) => {
            const cells = row.querySelectorAll('td');
            const titleCell = cells[1];
            const title = titleCell?.innerText?.trim() || '';
            const link = titleCell?.querySelector('a')?.href || '';
            const authors = cells[2]?.innerText?.trim() || '';
            const source = cells[3]?.innerText?.trim() || '';
            const date = cells[4]?.innerText?.trim() || '';
            return { title, url: link, authors, source, date };
        })
    '''])
    
    try:
        if output.strip().startswith('['):
            return json.loads(output)
    except:
        pass
    return []


def fetch_cnki_papers(keywords: List[str], max_papers: int = 10) -> List[Dict]:
    """从 CNKI 获取论文"""
    if not check_browser():
        print("Browser not available. Please start agent-browser with CDP port.")
        return []
    
    # 确保在知网页面
    open_cnki()
    
    # 直接获取当前搜索结果（不需要再次搜索，浏览器已显示结果）
    results = get_search_results()
    
    # 转换为统一格式
    papers = []
    for p in results[:max_papers]:
        papers.append({
            'id': p.get('url', ''),
            'title': p.get('title', ''),
            'summary': '',
            'published': p.get('date', ''),
            'authors': p.get('authors', '').split(','),
            'categories': ['CNKI'],
            'pdf_url': p.get('url', ''),
            'source': 'cnki',
        })
    
    return papers


if __name__ == '__main__':
    papers = fetch_cnki_papers(['LLM', '大模型'], max_papers=5)
    for p in papers:
        print(f"- {p['title']}")