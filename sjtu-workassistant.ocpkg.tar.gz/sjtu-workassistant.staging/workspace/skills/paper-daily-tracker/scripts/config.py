#!/usr/bin/env python3
"""
配置加载模块
支持 .env 文件和环境变量
"""

import os
import sys
from pathlib import Path
from typing import Dict, Any, Optional, List

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(dotenv_path: Optional[str] = None):
        if dotenv_path is None:
            dotenv_path = '.env'
        env_path = Path(dotenv_path)
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key.strip()] = value.strip()


def parse_list(value: Optional[str]) -> List[str]:
    """解析逗号分隔的列表"""
    if not value:
        return []
    return [item.strip() for item in value.split(',') if item.strip()]


def load_config() -> Dict[str, Any]:
    """加载配置"""
    load_dotenv()

    config = {
        'sources': parse_list(os.environ.get('SOURCES', 'arxiv')),
        
        'arxiv': {
            'categories': parse_list(os.environ.get('ARXIV_CATEGORIES', 'cs.AI,cs.LG,cs.CL,cs.CV')),
            'days': int(os.environ.get('ARXIV_DAYS', '1')),
        },
        
        'cnki': {
            'keywords': parse_list(os.environ.get('CNKI_KEYWORDS', '')),
        },
        
        'filter': {
            'keywords': parse_list(os.environ.get('KEYWORDS', '')),
            'exclude_keywords': parse_list(os.environ.get('EXCLUDE_KEYWORDS', '')),
            'max_papers': int(os.environ.get('MAX_PAPERS', '20')),
            'max_papers_per_source': int(os.environ.get('MAX_PAPERS_PER_SOURCE', '10')),
        },
        
        'features': {
            'enable_translation': os.environ.get('ENABLE_TRANSLATION', 'true').lower() == 'true',
            'translation_mode': os.environ.get('TRANSLATION_MODE', 'summary'),  # summary or full
            'enable_email': os.environ.get('ENABLE_EMAIL', 'true').lower() == 'true',
            'enable_dedup': os.environ.get('ENABLE_DEDUP', 'true').lower() == 'true',
        },
        
        'llm': {
            'api_url': os.environ.get('LLM_API_URL', ''),
            'api_key': os.environ.get('LLM_API_KEY', ''),
            'model': os.environ.get('LLM_MODEL', ''),
            'timeout': int(os.environ.get('LLM_TIMEOUT', '600')),
            'source_lang': os.environ.get('LLM_SOURCE_LANG', 'English'),
            'target_lang': os.environ.get('LLM_TARGET_LANG', 'Chinese'),
        },
        
        'email': {
            'smtp_host': os.environ.get('SMTP_HOST', 'mail.sjtu.edu.cn'),
            'smtp_port': int(os.environ.get('SMTP_PORT', '465')),
            'smtp_user': os.environ.get('SMTP_USER', ''),
            'smtp_password': os.environ.get('SMTP_PASSWORD', ''),
            'from': os.environ.get('EMAIL_FROM', ''),
            'to': os.environ.get('EMAIL_TO', ''),
            'subject': os.environ.get('EMAIL_SUBJECT', '论文简报'),
        },
        
        'temp_dir': os.environ.get('TEMP_DIR', 'temp'),
    }

    return config


def init_config():
    """初始化配置文件"""
    env_file = Path('.env')
    example_file = Path(__file__).parent.parent / 'assets' / '.env.example'

    if env_file.exists():
        print(f".env already exists: {env_file}")
        return

    if example_file.exists():
        import shutil
        shutil.copy(example_file, env_file)
        print(f"Config file created: {env_file}")
        print("Please edit it with your settings.")
    else:
        print("Error: .env.example not found")
        sys.exit(1)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'init':
        init_config()
    else:
        config = load_config()
        print("Current config:")
        print(f"  Sources: {config['sources']}")
        print(f"  arXiv categories: {config['arxiv']['categories']}")
        print(f"  Keywords: {config['filter']['keywords']}")
        print(f"  Max papers: {config['filter']['max_papers']}")
        print(f"  Translation: {config['features']['enable_translation']}")
        print(f"  Email: {config['features']['enable_email']}")