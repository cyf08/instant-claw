#!/usr/bin/env python3
"""
邮件发送脚本
发送包含 PDF 附件的邮件
"""

import sys
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import Optional


def load_config(config_file: str) -> dict:
    """加载配置文件 (.env 格式)"""
    # 使用 config.py 加载
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(script_dir)
    config_py = os.path.join(parent_dir, 'scripts', 'config.py')

    if os.path.exists(config_py):
        import importlib.util
        spec = importlib.util.spec_from_file_location("config", config_py)
        config_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(config_module)
        return config_module.load_config()

    # Fallback: 简单解析 .env
    env_file = '.env'
    if os.path.exists(env_file):
        config = {}
        with open(env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    config[key.strip()] = value.strip()
        return {'email': config}
    return {}


def resolve_env_vars(config: dict) -> dict:
    """解析环境变量"""
    result = {}
    for key, value in config.items():
        if isinstance(value, dict):
            result[key] = resolve_env_vars(value)
        elif isinstance(value, str) and value.startswith('${') and value.endswith('}'):
            env_var = value[2:-1]
            result[key] = os.environ.get(env_var, '')
        else:
            result[key] = value
    return result


def send_email(
    smtp_host: str,
    smtp_port: int,
    smtp_user: str,
    smtp_password: str,
    from_email: str,
    to_email: str,
    subject: str,
    body: str,
    attachment_path: Optional[str] = None
) -> bool:
    """发送邮件"""
    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'html', 'utf-8'))

    # 添加附件
    if attachment_path and os.path.exists(attachment_path):
        with open(attachment_path, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
        encoders.encode_base64(part)
        filename = os.path.basename(attachment_path)
        part.add_header(
            'Content-Disposition',
            f'attachment; filename= {filename}'
        )
        msg.attach(part)

    try:
        # 使用 SSL
        server = smtplib.SMTP_SSL(smtp_host, smtp_port)
        server.login(smtp_user, smtp_password)
        server.sendmail(from_email, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Error sending email: {e}", file=sys.stderr)
        return False


def main():
    config_file = sys.argv[1] if len(sys.argv) > 1 else 'arxiv-daily.yaml'

    # 加载配置
    config = load_config(config_file)
    config = resolve_env_vars(config)

    email_config = config.get('email', {})
    smtp_host = email_config.get('smtp_host', 'mail.sjtu.edu.cn')
    smtp_port = email_config.get('smtp_port', 465)
    smtp_user = email_config.get('smtp_user', '')
    smtp_password = email_config.get('smtp_password', '')
    from_email = email_config.get('from', smtp_user)
    to_email = email_config.get('to', '')

    # 检查配置
    if not smtp_user or not smtp_password or not to_email:
        print("Error: Missing email configuration", file=sys.stderr)
        print("Please set EMAIL_USER, EMAIL_PASSWORD, EMAIL_TO environment variables", file=sys.stderr)
        sys.exit(1)

    # 解析命令行参数
    if len(sys.argv) < 3:
        print("Usage: send_email.py <config_file> <subject> <body_html> [attachment_pdf]")
        sys.exit(1)

    subject = sys.argv[2]
    body_html = sys.argv[3]
    attachment = sys.argv[4] if len(sys.argv) > 4 else None

    # 发送邮件
    success = send_email(
        smtp_host=smtp_host,
        smtp_port=smtp_port,
        smtp_user=smtp_user,
        smtp_password=smtp_password,
        from_email=from_email,
        to_email=to_email,
        subject=subject,
        body=body_html,
        attachment_path=attachment
    )

    if success:
        print(f"Email sent successfully to {to_email}")
    else:
        print("Failed to send email", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()