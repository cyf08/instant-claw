#!/bin/bash
# arXiv API 抓取脚本
# 用法: ./fetch_rss.sh <category> [max_results] [output_file]

set -e

CATEGORY="${1:-cs.AI}"
MAX_RESULTS="${2:-50}"
OUTPUT_FILE="${3:-/tmp/arxiv_${CATEGORY}.xml}"

ARXIV_API_URL="https://export.arxiv.org/api/query"

echo "Fetching arXiv API for category: ${CATEGORY}"

curl -sL -o "${OUTPUT_FILE}" "https://export.arxiv.org/api/query?search_query=cat:${CATEGORY}&max_results=${MAX_RESULTS}&sortBy=submittedDate&sortOrder=descending"

if [ -f "${OUTPUT_FILE}" ] && [ -s "${OUTPUT_FILE}" ]; then
    echo "Saved to: ${OUTPUT_FILE}"
    echo "File size: $(wc -c < "${OUTPUT_FILE}") bytes"
else
    echo "Error: Failed to fetch arXiv API"
    exit 1
fi