#!/bin/bash
# PaperMind 部署脚本
# 自动克隆并部署 PaperMind 服务

set -e

PAPERMIND_DIR="${1:-./PaperMind}"

echo "=== PaperMind 部署脚本 ==="
echo "目标目录: ${PAPERMIND_DIR}"

# 检查 Docker
if ! command -v docker &> /dev/null; then
    echo "Error: Docker 未安装"
    exit 1
fi

if ! command -v docker compose &> /dev/null; then
    echo "Error: docker compose 未安装"
    exit 1
fi

# 克隆 PaperMind（如果不存在）
if [ ! -d "${PAPERMIND_DIR}" ]; then
    echo "Cloning PaperMind..."
    git clone https://github.com/Color2333/PaperMind.git "${PAPERMIND_DIR}"
fi

cd "${PAPERMIND_DIR}"

# 检查 .env 文件
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        cp .env.example .env
        echo "已创建 .env 文件，请编辑填入 API Key:"
        echo "  - LLM_PROVIDER: openai/anthropic/zhipu"
        echo "  - ZHIPU_API_KEY / OPENAI_API_KEY / ANTHROPIC_API_KEY"
        echo ""
        echo "编辑后运行: docker compose up -d --build"
        exit 0
    else
        echo "Error: .env.example 不存在"
        exit 1
    fi
fi

# 确认是否启动
echo ""
read -p "是否启动 PaperMind 服务? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Building and starting PaperMind..."
    docker compose up -d --build

    echo ""
    echo "=== PaperMind 启动完成 ==="
    echo "前端: http://localhost:3002"
    echo "后端: http://localhost:8002"
    echo "API 文档: http://localhost:8002/docs"
else
    echo "已取消。可手动启动: cd ${PAPERMIND_DIR} && docker compose up -d --build"
fi