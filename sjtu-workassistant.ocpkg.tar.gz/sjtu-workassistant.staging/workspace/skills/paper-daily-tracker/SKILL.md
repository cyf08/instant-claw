---
name: paper-daily-tracker
description: 自动收集 arXiv/CNKI 论文，按关键词筛选、翻译、生成 PDF，并可通过邮件发送每日论文报告。用于用户要求每日论文追踪、arXiv/CNKI 检索、论文日报、论文筛选、翻译摘要、生成 PDF 报告或定时推送时。
---

# Paper Daily Finder

自动收集 arXiv/CNKI 论文，翻译后生成 PDF 发送邮件。

## 快速开始

```bash
# 1. 复制配置模板
cp assets/.env.example .env

# 2. 编辑配置 (数据源、关键词、邮箱等)
vim .env

# 3. 运行（需要先启动 agent-browser）
# 终端1: 启动 CDP 浏览器	agent-browser
# 或 agent-browser open https://kns.cnki.net/kns8s/defaultresult/index

# 终端2: 运行抓取
python scripts/run.py fetch

# 4. 定时任务（需要在有浏览器的机器上）
openclaw cron add --name paper-daily --cron "0 9 * * *" --message "python scripts/run.py fetch"
```

## 依赖要求

| 组件 | 要求 | 说明 |
|------|------|------|
| arXiv | ✅ 可用 | 直接 API 调用 |
| CNKI | ⚠️ 需要浏览器 | 必须先启动 agent-browser 并登录知网 |
| 邮件 | ✅ 可用 | SMTP 配置正确即可 |

## 配置说明

主要配置项在 `.env` 文件中：

| 配置 | 说明 |
|------|------|
| `SOURCES` | 数据源: arxiv, cnki |
| `ARXIV_CATEGORIES` | arXiv 分类 |
| `CNKI_KEYWORDS` | CNKI 搜索关键词 |
| `KEYWORDS` | 过滤关键词 |
| `ENABLE_TRANSLATION` | 是否翻译 |
| `ENABLE_EMAIL` | 是否发邮件 |
| `ENABLE_DEDUP` | 是否去重 |

详细配置见 `assets/CONFIG.md`
