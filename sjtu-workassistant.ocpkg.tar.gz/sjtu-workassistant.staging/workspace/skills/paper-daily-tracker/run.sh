#!/bin/bash
cd ~/.openclaw/workspace/connor/skills/paper-daily-tracker
export PYTHONPATH=./scripts
export DOTENV_PATH=.env
python3 -c "
import os
os.chdir('/root/.openclaw/workspace/connor/skills/paper-daily-tracker')
from config import load_config
c = load_config()
print('Sources:', c.get('sources'))
print('Keywords:', c.get('filter', {}).get('keywords'))
from fetchers import fetch_arxiv_papers, fetch_cnki_papers

print('=== arXiv ===')
papers = fetch_arxiv_papers(c.get('arxiv', {}).get('categories', ['cs.AI']), days=7, max_papers=5)
print(f'Fetched {len(papers)} papers')

print('=== CNKI ===')
papers2 = fetch_cnki_papers(c.get('cnki', {}).get('keywords', []), max_papers=10)
print(f'Fetched {len(papers2)} papers')
"
