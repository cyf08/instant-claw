#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from email_manager import load_config, get_email_manager

config = load_config()
print("Config loaded:", config.get('default_mailbox'))

# 使用 exmail 类型（因为配置里用的是 exmail_email）
manager = get_email_manager('exmail', config)
print("Manager created:", manager.smtp_server, manager.smtp_port)

# 测试发送
result = manager.send_email(
    to_addr='zhangzb@sjtu.edu.cn',
    subject='测试邮件',
    content='这是一封测试邮件'
)
print(result)