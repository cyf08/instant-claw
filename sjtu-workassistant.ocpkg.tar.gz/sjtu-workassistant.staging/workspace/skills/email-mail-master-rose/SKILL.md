---
name: email-mail-master 万能邮箱助手
description: 通过阿里云邮箱、QQ邮箱、163邮箱、上海交大邮箱等发送和接收邮件。支持发送普通邮件、带附件邮件、接收邮件、检查新邮件、草稿管理。当用户要求发送邮件、查看邮件、检查新邮件、写草稿时使用。

---

# ⚠️ 安全声明

**未经用户明确允许，禁止删除任何邮件（包括草稿）。**

如需删除操作，必须先征求用户同意。

---

# 邮件管理

通过阿里云邮箱、QQ邮箱、163邮箱、上海交大邮箱等发送和接收邮件。

## 配置

编辑 `scripts/config.json`，填写邮箱地址和授权码（非登录密码）。

### 上海交大邮箱配置示例

```json
{
  "default_mailbox": "sjtu",
  "sjtu_email": {
    "email": "your_email@sjtu.edu.cn",
    "auth_password": "your_password",
    "imap_server": "mail.sjtu.edu.cn",
    "imap_port": 993,
    "smtp_server": "mail.sjtu.edu.cn",
    "smtp_port": 465
  }
}
```

### 授权码获取

- QQ 邮箱：设置 > 账户 > 开启 IMAP/SMTP > 生成授权码
- 163 邮箱：设置 > POP3/SMTP/IMAP > 开启服务 > 设置授权密码
- 上海交大邮箱：登录 mail.sjtu.edu.cn，设置 > 客户端设置 > 开启 IMAP/SMTP

可通过 `default_mailbox` 字段设置默认邮箱（`"qq"`、`"163"`、`"sjtu"`）。

## 命令行调用

```bash
# 发送邮件
python3 mail.py send --to user@example.com --subject "主题" --content "内容"

# 发送带附件
python3 mail.py send --to user@example.com --subject "报告" --content "请查收" --attach report.pdf

# 接收最新邮件
python3 mail.py receive --limit 5

# 接收邮件（JSON 输出，推荐 AI 使用）
python3 mail.py receive --limit 5 --json

# 检查新邮件（最近 N 天）
python3 mail.py check-new --since 1

# 检查新邮件（JSON 输出）
python3 mail.py check-new --since 1 --json

# 删除邮件（移到已删除文件夹，可恢复）
python3 mail.py delete --ids 123

# 批量删除
python3 mail.py delete --ids 123 124 125

# 彻底删除（不可恢复）
python3 mail.py delete --ids 123 --permanent

# 指定邮箱类型
python3 mail.py --mailbox sjtu send --to user@example.com --subject "测试"
```

## 草稿功能

```bash
# 创建草稿
python3 mail.py draft-create --to "收件人@example.com" --subject "主题" --content "内容"

# 列出草稿箱
python3 mail.py draft-list

# 发送草稿
python3 mail.py draft-send <草稿ID>
```

### 草稿功能使用示例

```bash
# 1. 创建草稿
python3 mail.py draft-create --to "zhangzb@sjtu.edu.cn" --subject "项目报告" --content "详见附件"

# 2. 查看草稿
python3 mail.py draft-list

# 3. 发送草稿（假设 ID 为 1）
python3 mail.py draft-send 1
```

## 沙箱限制问题

如果遇到 `exec preflight: complex interpreter invocation detected` 错误，使用 `host=gateway` 参数：

```bash
# 方式1：直接指定完整路径
/usr/bin/python3 /path/to/mail.py [command]

# 方式2：在 OpenClaw 中使用
exec /usr/bin/python3 /path/to/mail.py [command] --host gateway
```

## 删除邮件说明

- IMAP 邮箱（QQ、上海交大）：默认移到「已删除」文件夹，可以从已删除中恢复。加 `--permanent` 彻底删除。
- POP3 邮箱（163）：POP3 协议不支持文件夹操作，删除始终是永久的，不可恢复。

## 上海交大邮箱服务器

| 协议 | 服务器 | 端口 | 加密 |
|------|--------|------|------|
| IMAP | mail.sjtu.edu.cn | 993 | SSL |
| SMTP | mail.sjtu.edu.cn | 465 | SSL |
| POP3 | mail.sjtu.edu.cn | 995 | SSL |