# Tools

Preferred stack:
- OpenClaw CLI
- clawpacker for portable agent packages
- Markdown for office knowledge and templates
- Python 3.11+ for document, spreadsheet, and data helpers when later skills provide scripts

Expected materials:
- SJTU notices, policies, forms, and procedure pages
- PDF, Word, Excel, Markdown, plain text, web pages, email drafts, and meeting notes
- Chinese and English office communications

Packaging notes:
- Workspace: `/home/hpccyf/Projects/sjtu-workassistant`
- Profile: `sjtu-workassistant`
- Agent ID: `sjtu-workassistant`
- Config: `/home/hpccyf/.openclaw-sjtu-workassistant/openclaw.json`

Common commands:

```bash
openclaw --profile sjtu-workassistant agents list
openclaw --profile sjtu-workassistant skills install <skill-slug>
clawpacker inspect \
  --workspace /home/hpccyf/Projects/sjtu-workassistant \
  --config /home/hpccyf/.openclaw-sjtu-workassistant/openclaw.json \
  --agent-id sjtu-workassistant \
  --runtime-mode none
clawpacker export \
  --workspace /home/hpccyf/Projects/sjtu-workassistant \
  --config /home/hpccyf/.openclaw-sjtu-workassistant/openclaw.json \
  --agent-id sjtu-workassistant \
  --runtime-mode none \
  --name sjtu-workassistant \
  --out /home/hpccyf/Projects/instant-claw/sjtu-workassistant \
  --archive
```
