# sjtu-workassistant

OpenClaw agent workspace for 交大办公助手.

Installed workspace skills:

- `sjtu-canvas` from `https://github.com/xhh678876/openclaw-sjtu`
- `lobster-square` from the same repository's `skills/lobster-square` subdirectory
- `agent-browser` from `/home/hpccyf/Projects/skills.zip`
- `email-mail-master-rose` from `/home/hpccyf/Projects/skills.zip`
- `martok9803-reminder-engine` from `/home/hpccyf/Projects/skills.zip`
- `paper-daily-tracker` from `/home/hpccyf/Projects/skills.zip`
- `minimax-docx` from ClawHub
- `minimax-xlsx` from ClawHub
- `minimax-pdf` from ClawHub
- `pptx-generator` from ClawHub

Add more skills later under `skills/`, keep `skills-lock.json` updated, and export the workspace with `clawpacker`.

## Runtime Notes

The MiniMax office-document skills are packaged as workspace skills, but target machines still need their runtime tools:

- `minimax-docx`: Python 3 and .NET 9 SDK; LibreOffice, Pandoc, matplotlib, Playwright, and Pillow are optional helpers.
- `minimax-xlsx`: Python packages such as `openpyxl` and `pandas`; LibreOffice is used for headless formula recalculation.
- `minimax-pdf`: OpenClaw's HTML-to-PDF runtime/tooling.
- `pptx-generator`: Python 3 plus `python-pptx` and `pillow`.

On this machine, LibreOffice is present and a user-local .NET SDK is available at `/home/hpccyf/.dotnet`; Python office packages and Pandoc may still need to be installed before running the document-generation workflows.

## Quick Checks

```bash
openclaw --profile sjtu-workassistant agents list
clawpacker inspect \
  --workspace /home/hpccyf/Projects/sjtu-workassistant \
  --config /home/hpccyf/.openclaw-sjtu-workassistant/openclaw.json \
  --agent-id sjtu-workassistant \
  --runtime-mode none
```

## Install Skills Later

```bash
openclaw --profile sjtu-workassistant skills install <skill-slug>
```

For GitHub-backed or local archive skills that are not on ClawHub, copy the skill directory into `skills/`, update `skills-lock.json`, then run `clawpacker inspect`.

## Package

```bash
clawpacker export \
  --workspace /home/hpccyf/Projects/sjtu-workassistant \
  --config /home/hpccyf/.openclaw-sjtu-workassistant/openclaw.json \
  --agent-id sjtu-workassistant \
  --runtime-mode none \
  --name sjtu-workassistant \
  --out /home/hpccyf/Projects/instant-claw/sjtu-workassistant \
  --archive
```
