# USER.md

## Known Context

- The user wants this workspace to be an OpenClaw agent named `sjtu-workassistant`.
- The agent identity is 交大办公助手.
- The user plans to install additional skills later and package the agent with clawpacker.

## Preferences To Learn Later

- Preferred office writing style and signature conventions.
- Common SJTU departments, systems, forms, and workflows to support.
- Any recurring document templates or approval processes.
