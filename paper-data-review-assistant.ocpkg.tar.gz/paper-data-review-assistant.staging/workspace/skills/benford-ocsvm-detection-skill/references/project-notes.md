# Benford-OCSVM-Detection-System88 Notes

Source repository: `https://github.com/solaire85/Benford-OCSVM-Detection-System88`

Article context: recommended in Tencent Cloud article `https://cloud.tencent.com/developer/article/2679768` as a tool combining Benford-law statistics with OCSVM anomaly detection for paper-data auditing.

## Repository Shape

- `app.py`: Flask app and core algorithm implementation.
- `data/*.xlsx`: baseline datasets for WDI amounts, GDP growth, and COVID data.
- `templates/`, `static/`: web UI.
- `说明书.docx`: project manual.
- `requirements.txt`: present but empty as of the inspected commit.

## Core Algorithm

The app computes Benford feature windows and fits One-Class SVM:

- `improved_benford_test(data)`: first-digit Benford distribution, chi-square-like statistic, MAD, Pearson correlation, confidence features.
- `generate_benford_feature_matrix(data, window=40, step=1)`: rolling-window feature matrix.
- `run_analysis_pipeline(train_values, test_values, window_size=40, nu=0.05)`: train OCSVM on baseline features, score test features, set threshold at the 5th percentile of train scores.

The bundled CLI in this skill mirrors that logic so Codex can run headless checks without launching Flask.

## Flask Usage

Clone and run from the repository root:

```bash
git clone https://github.com/solaire85/Benford-OCSVM-Detection-System88.git
cd Benford-OCSVM-Detection-System88
pip install flask numpy pandas matplotlib seaborn scipy scikit-learn openpyxl xlsxwriter pdfkit
python app.py
```

Then open `http://127.0.0.1:5000`.

Important routes:

- `/`: upload UI.
- `/analyze`: main analysis form; fields include `data_source`, `preset_type`, `train_file`, `test_file`, `window_size`, and `nu_param`.
- `/export_report`: Excel export.
- `/export_pdf`: PDF export.

## Known Quirks

- `requirements.txt` is empty, so dependencies must be inferred.
- `pdfkit.configuration(...)` points to `C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe`; startup or PDF export may fail if wkhtmltopdf is absent.
- `app.py` constructs `Flask(__name__)` twice. Running from the repo root is safest because the second construction relies on default template/static paths.
- Use the project as a screening aid only. Benford-law deviations can arise from legitimate bounded distributions, preprocessing, rounding, censoring, or extraction errors.
