#!/usr/bin/env python
"""Headless Benford + OCSVM screening for CSV/XLSX numeric data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from sklearn.svm import OneClassSVM


def load_table(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix == ".csv":
        return pd.read_csv(path)
    raise ValueError(f"Unsupported file type: {path.suffix}")


def numeric_values(df: pd.DataFrame, column: str | None) -> np.ndarray:
    if column:
        if column not in df.columns:
            raise ValueError(f"Column not found: {column}")
        series = pd.to_numeric(df[column], errors="coerce")
    else:
        numeric = df.apply(pd.to_numeric, errors="coerce").select_dtypes(include=[np.number])
        if numeric.empty:
            raise ValueError("No numeric columns found")
        series = numeric.stack(dropna=True)
    values = series.replace([np.inf, -np.inf], np.nan).dropna().astype(float).to_numpy()
    values = values[values > 0]
    if len(values) < 10:
        raise ValueError("Fewer than 10 positive numeric values after cleaning")
    return values


def first_digit(value: float) -> int | None:
    text = f"{abs(value):.15g}".replace(".", "").lstrip("0")
    if not text:
        return None
    digit = int(text[0])
    return digit if 1 <= digit <= 9 else None


def improved_benford_test(data: np.ndarray) -> dict[str, float]:
    data = np.asarray(data, dtype=float)
    data = data[data > 0]
    if len(data) < 10:
        raise ValueError("window has too few positive values")

    digits = [d for d in (first_digit(x) for x in data) if d is not None]
    obs_counts = np.array([digits.count(i) for i in range(1, 10)], dtype=float)
    if obs_counts.sum() == 0:
        raise ValueError("window has no valid first digits")

    obs = obs_counts / obs_counts.sum()
    benford = np.array([np.log10(1 + 1 / i) for i in range(1, 10)])
    chi2_stat = float(np.sum((obs - benford) ** 2 / benford))
    chi2_p = float(1 - np.exp(-chi2_stat))
    mad = float(np.mean(np.abs(obs - benford)))
    mad_conf = float(max(0, 1 - mad / 0.015))
    corr, _ = pearsonr(obs, benford)
    corr = float(corr)
    corr_conf = float((corr + 1) / 2)
    consistency = float((mad_conf + corr_conf) / 2)
    combined_conf = float((consistency + (1 - chi2_p)) / 2)

    return {
        "chi2": chi2_stat,
        "chi2_p": chi2_p,
        "mad": mad,
        "mad_conf": mad_conf,
        "corr": corr,
        "corr_conf": corr_conf,
        "consistency": consistency,
        "combined_conf": combined_conf,
    }


def feature_matrix(values: np.ndarray, window: int, step: int) -> tuple[pd.DataFrame, list[tuple[int, int]]]:
    rows: list[dict[str, float]] = []
    spans: list[tuple[int, int]] = []
    for start in range(0, len(values) - window + 1, step):
        try:
            rows.append(improved_benford_test(values[start : start + window]))
            spans.append((start + 1, start + window))
        except ValueError:
            continue
    if not rows:
        raise ValueError("No valid windows generated; reduce window size or provide more positive values")
    return pd.DataFrame(rows), spans


def run(train_values: np.ndarray, test_values: np.ndarray, window_size: int, step: int, nu: float) -> tuple[pd.DataFrame, float]:
    train_features, _ = feature_matrix(train_values, window_size, step)
    test_features, spans = feature_matrix(test_values, window_size, step)
    if len(train_features) < 5:
        raise ValueError("Baseline generated fewer than 5 valid windows")

    model = OneClassSVM(kernel="rbf", nu=nu, gamma="scale")
    model.fit(train_features.to_numpy())
    train_scores = model.decision_function(train_features.to_numpy())
    test_scores = model.decision_function(test_features.to_numpy())
    threshold = float(np.percentile(train_scores, 5))

    results = test_features.copy()
    results.insert(0, "start_row", [s[0] for s in spans])
    results.insert(1, "end_row", [s[1] for s in spans])
    results["OCSVM_Score"] = test_scores
    results["Is_Abnormal"] = (test_scores < threshold).astype(int)
    return results, threshold


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Benford-law feature screening with One-Class SVM.")
    parser.add_argument("--train", required=True, type=Path, help="Baseline CSV/XLSX file")
    parser.add_argument("--test", required=True, type=Path, help="Test CSV/XLSX file")
    parser.add_argument("--train-column", help="Baseline numeric column; omit to stack all numeric columns")
    parser.add_argument("--test-column", help="Test numeric column; omit to stack all numeric columns")
    parser.add_argument("--window-size", type=int, default=40)
    parser.add_argument("--step", type=int, default=1)
    parser.add_argument("--nu", type=float, default=0.05, help="Expected anomaly fraction for OCSVM")
    parser.add_argument("--output", type=Path, help="JSON output path")
    parser.add_argument("--excel", type=Path, help="Optional XLSX output path for detailed windows")
    args = parser.parse_args()

    train_df = load_table(args.train)
    test_df = load_table(args.test)
    train_values = numeric_values(train_df, args.train_column)
    test_values = numeric_values(test_df, args.test_column)
    results, threshold = run(train_values, test_values, args.window_size, args.step, args.nu)

    abnormal = int(results["Is_Abnormal"].sum())
    summary = {
        "train_file": str(args.train),
        "test_file": str(args.test),
        "train_column": args.train_column,
        "test_column": args.test_column,
        "window_size": args.window_size,
        "step": args.step,
        "nu": args.nu,
        "threshold": threshold,
        "analyzed_windows": int(len(results)),
        "abnormal_windows": abnormal,
        "abnormal_rate": abnormal / len(results) if len(results) else 0,
        "top_abnormal_windows": results.sort_values("OCSVM_Score").head(10).to_dict(orient="records"),
    }

    payload = json.dumps(summary, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(payload, encoding="utf-8")
    else:
        print(payload)

    if args.excel:
        with pd.ExcelWriter(args.excel, engine="xlsxwriter") as writer:
            pd.DataFrame([summary | {"top_abnormal_windows": json.dumps(summary["top_abnormal_windows"], ensure_ascii=False)}]).to_excel(
                writer, sheet_name="summary", index=False
            )
            results.to_excel(writer, sheet_name="windows", index=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
