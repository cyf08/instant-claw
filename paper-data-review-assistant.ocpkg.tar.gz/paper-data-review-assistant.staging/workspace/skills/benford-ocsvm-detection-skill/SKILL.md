---
name: benford-ocsvm-detection
description: Screen tabular research, biomedical, economics, public-health, or extracted paper data for statistical anomalies using Benford's Law features and One-Class SVM windows. Use when Codex needs to wrap or run the non-skill GitHub project solaire85/Benford-OCSVM-Detection-System88, audit numeric CSV/XLSX data from papers, compare a baseline dataset with a suspect dataset, flag anomalous row windows, or explain Benford/OCSVM detection results.
---

# Benford OCSVM Detection

## Quick Start

Use this skill for numeric-data triage, not as proof of fraud. Treat findings as screening signals that require source-data review, domain context, and reproducibility checks.

For a headless audit, prefer the bundled CLI:

```bash
python scripts/run_benford_ocsvm.py --train baseline.xlsx --test paper_data.xlsx --output report.json --excel report.xlsx
```

For the original web app, clone `https://github.com/solaire85/Benford-OCSVM-Detection-System88`, install dependencies, run `python app.py` from the repo root, and open `http://127.0.0.1:5000`.

## Workflow

1. Collect a baseline dataset and a test dataset. Use CSV/XLSX files with enough positive numeric values; the default window size of 40 needs at least 40 usable numbers in the test file and several windows in the baseline file.
2. Extract only meaningful measurement/count/amount columns. Exclude IDs, years, page numbers, group labels, Likert codes, categorical encodings, and values that are constrained to a narrow artificial range.
3. Run the CLI with explicit columns when possible:

```bash
python scripts/run_benford_ocsvm.py --train baseline.xlsx --test suspect.xlsx --train-column value --test-column value --window-size 40 --nu 0.05 --output result.json
```

4. Interpret `abnormal_rate`, abnormal row windows, and OCSVM scores as prioritization for manual review. Higher abnormal rates or clustered abnormal windows deserve inspection of raw records, extraction quality, and experimental protocol.
5. Document limitations: Benford checks work best on naturally varying, multi-order-of-magnitude positive values. They can be weak or misleading for small samples, rounded values, bounded assays, percentages, ranks, or transformed statistics.

## Original Project Notes

Read `references/project-notes.md` when you need details about the source repository, dependencies, Flask routes, and known quirks.

The original repository's `requirements.txt` is empty. If running the Flask app, install at least:

```bash
pip install flask numpy pandas matplotlib seaborn scipy scikit-learn openpyxl xlsxwriter pdfkit
```

PDF export additionally needs `wkhtmltopdf` at the path configured in `app.py`, or the app code must be adjusted before startup.

## Output Guidance

When reporting results, include:

- Dataset names and selected columns.
- Window size and `nu`.
- Number of analyzed windows and abnormal windows.
- Top abnormal windows by lowest OCSVM score.
- A plain-language caution that this is anomaly screening, not a definitive misconduct finding.
