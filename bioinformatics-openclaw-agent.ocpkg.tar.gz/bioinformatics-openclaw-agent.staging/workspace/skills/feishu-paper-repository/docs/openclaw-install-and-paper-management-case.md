# 在 OpenClaw 上安装 Feishu Paper Repository Skill 并管理论文仓库

本文档记录如何在 OpenClaw 中安装 `feishu-paper-repository` skill，并用它完成一次“检索论文、上传 PDF、维护飞书分类索引”的论文管理流程。

## 1. 论文检索来源

`feishu-paper-repository` 的论文检索部分参考并衔接
[`ustc-ai4science/academic-search`](https://github.com/ustc-ai4science/academic-search)
的工作流设计。

`academic-search` 提供论文检索、引用分析、元数据提取、PDF 发现、BibTeX 导出、多源去重等能力，覆盖 arXiv、Semantic Scholar、Google Scholar、PubMed、CNKI 等常见学术来源。它的核心策略包括：

- API 优先，必要时使用浏览器/CDP 兜底。
- 对用户查询进行 query 扩展。
- 先进行轻量检索和摘要筛选，再深拉完整元数据。
- 按 DOI、arXiv ID、PMID、Semantic Scholar ID 和标题去重。
- 对 429、空结果、超时等失败信号切换检索路径。

`feishu-paper-repository` 在这些检索策略之上增加飞书论文仓库管理能力：检查飞书权限、上传论文 PDF、维护分类目录、创建或更新每个分类唯一的飞书云文档索引。

## 2. 目标

`feishu-paper-repository` 适合把 OpenClaw 变成一个论文管理助手，例如“小查”：

- 检索期刊、会议和预印本论文。
- 下载开放授权或用户确认可保存的 PDF。
- 按主题分类上传到飞书云盘。
- 每个分类目录只维护一个飞书云文档索引。
- 后续新增论文时更新同一个分类索引，而不是重复上传索引文件。

## 3. 前置条件

本案例假设已经具备：

- OpenClaw 已安装。
- Node.js 22+ 可用。
- `lark-cli` 已安装。
- OpenClaw 已启用 `openclaw-lark` 插件。
- 飞书 channel 已配置 app credentials。
- Chrome 或 Chromium 已安装并配置给 OpenClaw browser plugin。

## 4. 安装 Skill

推荐提供两种安装方式。

### 方式一：通过 OpenClaw 对话安装

直接对 OpenClaw 说：

```text
请帮我安装这个 skill：https://github.com/cyf08/feishu-paper-repository-skill
```

安装后，让 OpenClaw 确认 `feishu-paper-repository` 是否已经显示为 `Ready`。

### 方式二：通过 git clone 安装

如果希望手动安装到当前持久 workspace：

```bash
mkdir -p "$HOME/.openclaw/workspace/skills"
git clone https://github.com/cyf08/feishu-paper-repository-skill \
  "$HOME/.openclaw/workspace/skills/feishu-paper-repository"
```

如果目录已经存在，用 `git pull` 更新：

```bash
cd "$HOME/.openclaw/workspace/skills/feishu-paper-repository"
git pull
```

## 5. 飞书 CLI 和权限检查

配置飞书 CLI 时，不建议用户手动复制 token 或自己拼接授权命令。直接在 OpenClaw 对话中发送下面这句话，让 OpenClaw 按官方文档完成安装、绑定和授权流程：

```text
请按照该文档帮我安装飞书cli：https://open.feishu.cn/document/mcp_open_tools/feishu-cli/set-up-lark-cli-for-ai-agents-in-openclaw_hermes.md
```

OpenClaw 会引导用户选择工作身份、安装 `lark-cli`、绑定 OpenClaw 飞书配置，并在需要用户授权时给出飞书授权链接。

推荐选择用户身份模式，因为个人云盘论文仓库通常需要以用户身份创建文件夹、上传 PDF、创建和移动飞书文档。授权链接必须由用户在自己的浏览器中打开完成，不要让 agent 自己打开授权页面。

完成后可以让 OpenClaw 或用户运行状态检查：

```bash
lark-cli auth status
```

期望满足：

- `identity` 是 `user`。
- `tokenStatus` 是 `valid` 或 `needs_refresh`。

## 6. 论文管理案例

案例目标：

> 搜索 2024 年以来大模型可解释性相关的顶会和高分论文，下载 10 篇重点论文，上传到飞书云盘“论文仓库/人工智能与机器学习”，并维护该分类的唯一索引文档。

可以对 OpenClaw 说：

```text
小查，帮我搜索 2024 年以来大模型可解释性相关的顶会和高分论文，精选 10 篇开放 PDF，上传到飞书云盘的“论文仓库/人工智能与机器学习”，并更新这个分类的论文索引。
```

skill 应执行的流程：

1. 确认飞书 CLI 授权和目标分类目录可用。
2. 明确目标分类目录。
3. 检索候选论文。
4. 去重并筛选重点论文。
5. 下载开放授权 PDF。
6. 上传 PDF 到目标分类目录。
7. 查找该分类已有索引云文档。
8. 如果索引存在，更新该文档。
9. 如果索引不存在，创建一个 `<分类名>论文索引` 云文档。
10. 返回飞书目录链接、索引文档链接、上传数量和失败项。

## 7. 单索引策略

这个 skill 的当前策略是：

- 同一个飞书分类目录只保留一个论文索引云文档。
- 后续新增论文时，只维护这个云文档。
- 默认不上传 `README_论文索引.md`。
- Markdown 只作为本地临时生成内容。
- 只有用户明确要求“导出 Markdown”时，才上传 Markdown 索引文件。

推荐的索引文档标题：

```text
人工智能与机器学习论文索引
生物信息学论文索引
医学与临床论文索引
```

推荐索引结构：

```markdown
## Repository Summary

## Paper Table

| Status | Title | Year | Venue | Authors | Citation | PDF | Notes |
|---|---|---:|---|---|---:|---|---|

## Reading Plan

## Open Questions

## Change Log
```

## 8. 推荐目录结构

```text
论文仓库/
├── 人工智能与机器学习/
│   ├── 人工智能与机器学习论文索引   Feishu Doc
│   ├── Paper_A.pdf
│   └── Paper_B.pdf
├── 生物信息学/
│   ├── 生物信息学论文索引           Feishu Doc
│   └── Paper_C.pdf
└── 医学与临床/
    ├── 医学与临床论文索引           Feishu Doc
    └── Paper_D.pdf
```

## 9. 验收标准

完成一次论文管理任务后，应能确认：

- OpenClaw 能识别 `feishu-paper-repository` skill。
- 飞书目标分类目录中 PDF 上传成功。
- 该分类目录只有一个索引云文档。
- 新增论文已经追加到该索引云文档。
- 没有默认上传 `README_论文索引.md`。
- 最终回复包含分类目录链接、索引文档链接、论文数量和失败项。
