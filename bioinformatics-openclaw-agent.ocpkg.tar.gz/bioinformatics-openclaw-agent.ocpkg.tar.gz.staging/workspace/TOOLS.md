# TOOLS.md - Bioinformatics Tool Notes

This file records local conventions for the bioinformatics OpenClaw agent. Skills describe detailed workflows; this file describes how to operate in this workspace.

## Installed Skills

Scientific Agent Skills are installed under:

```bash
/home/hpccyf/.openclaw/workspace/skills
```

Source:

```text
https://github.com/K-Dense-AI/scientific-agent-skills
commit 25e1c0f5696f8f219069acfe70856a4a3d316397
```

Useful skill families:

- Omics: `scanpy`, `anndata`, `scvi-tools`, `scvelo`, `pydeseq2`, `gget`, `biopython`, `pysam`, `polars-bio`
- Databases: `database-lookup`, `bioservices`, `cellxgene-census`, `depmap`, `primekg`, `imaging-data-commons`
- Statistics and ML: `statistical-analysis`, `statsmodels`, `scikit-learn`, `shap`, `pymc`, `umap-learn`
- Drug discovery: `rdkit`, `datamol`, `deepchem`, `diffdock`, `medchem`, `molfeat`
- Communication: `literature-review`, `paper-lookup`, `citation-management`, `scientific-writing`, `peer-review`
- Figures: `matplotlib`, `seaborn`, `scientific-visualization`, `scientific-schematics`, `infographics`

## Environment Checks

Before running analysis, check local tooling:

```bash
python --version
uv --version
R --version
git --version
```

Prefer project-local environments:

```bash
uv venv
uv pip install -r requirements.txt
uv pip install scanpy anndata scipy pandas numpy matplotlib seaborn
```

Use the project's existing dependency manager if one is present (`pyproject.toml`, `uv.lock`, `environment.yml`, `renv.lock`, `Dockerfile`).

## Data Layout

Recommended project structure:

```text
data/raw/          immutable input files
data/interim/      normalized or converted intermediate files
data/processed/    analysis-ready matrices and tables
results/           figures, tables, model outputs
notebooks/         exploratory notebooks
scripts/           rerunnable pipeline steps
reports/           Markdown, PDF, slides, manuscripts
metadata/          sample sheets, data dictionaries, provenance
```

Never overwrite `data/raw/`. Put derived files in `data/interim/`, `data/processed/`, or `results/`.

## Common Commands

Inspect files:

```bash
rg --files
find . -maxdepth 3 -type f
du -sh *
```

Run Python checks:

```bash
python -m pytest
python -m ruff check .
python -m ruff format .
```

Single-cell quick checks:

```bash
python - <<'PY'
import scanpy as sc
adata = sc.read_h5ad("data/processed/input.h5ad")
print(adata)
print(adata.obs.head())
print(adata.var.head())
PY
```

FASTA/FASTQ/BAM work usually needs explicit reference genome/build and sample metadata before interpretation.

## External Services

External APIs and databases may be useful, but do not submit private human genomic, clinical, proprietary, or unpublished data without explicit user approval.

Safe-by-default lookups include public identifiers such as DOI, PMID, GEO/SRA accession, UniProt ID, Ensembl ID, HGNC symbol, PubChem CID, ChEMBL ID, and ClinicalTrials.gov NCT ID.

## Packaging

Use `clawpacker` from the OpenClaw state directory:

```bash
clawpacker inspect --workspace /home/hpccyf/.openclaw/workspace --config /home/hpccyf/.openclaw/openclaw.json
clawpacker export --workspace /home/hpccyf/.openclaw/workspace --config /home/hpccyf/.openclaw/openclaw.json --name bioinformatics-openclaw-agent --out /home/hpccyf/.openclaw/packages/bioinformatics-openclaw-agent.ocpkg.tar.gz --archive
```

Do not package credentials, sessions, or private datasets.
